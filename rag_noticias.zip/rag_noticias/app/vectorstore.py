"""
Capa de acceso a la base de datos vectorial (Qdrant).

Aquí viven las decisiones de ingeniería sobre almacenamiento y actualización:

  * Índice HNSW (búsqueda aproximada) configurable -> escala a millones de
    vectores con baja latencia y admite inserciones/borrados incrementales.
  * Índices de payload sobre `published_at` (DATETIME) y `source`/`category`/
    `language` (KEYWORD) -> filtrado eficiente por recencia y fuente.
  * IDs de punto DETERMINISTAS (uuid5 de article_id + chunk_index) -> el upsert
    es idempotente: reingerir un artículo ACTUALIZA en vez de duplicar.
  * Actualización a nivel de artículo: si cambia el hash del contenido, se
    borran los chunks antiguos del artículo y se insertan los nuevos.
  * Borrado por TTL: delete-by-filter sobre `published_at` para eliminar
    noticias obsoletas sin reconstruir el índice.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone

from qdrant_client import QdrantClient, models

from .config import config

# Espacio de nombres fijo para generar IDs deterministas de punto.
_NS = uuid.UUID("a1b2c3d4-0000-4000-8000-000000000000")


def punto_id(article_id: str, chunk_index: int) -> str:
    """ID determinista de un chunk: mismo artículo+índice -> mismo ID (idempotencia)."""
    return str(uuid.uuid5(_NS, f"{article_id}:{chunk_index}"))


_cliente: QdrantClient | None = None


def cliente() -> QdrantClient:
    global _cliente
    if _cliente is None:
        _cliente = QdrantClient(url=config.qdrant_url)
    return _cliente


def asegurar_coleccion() -> None:
    """Crea la colección y los índices de payload si no existen (idempotente)."""
    c = cliente()
    existentes = [x.name for x in c.get_collections().collections]
    if config.coleccion in existentes:
        return

    c.create_collection(
        collection_name=config.coleccion,
        vectors_config=models.VectorParams(
            size=config.dim_embedding, distance=models.Distance.COSINE
        ),
        hnsw_config=models.HnswConfigDiff(m=16, ef_construct=200),
    )
    c.create_payload_index(config.coleccion, "published_at", models.PayloadSchemaType.DATETIME)
    c.create_payload_index(config.coleccion, "source", models.PayloadSchemaType.KEYWORD)
    c.create_payload_index(config.coleccion, "category", models.PayloadSchemaType.KEYWORD)
    c.create_payload_index(config.coleccion, "language", models.PayloadSchemaType.KEYWORD)
    c.create_payload_index(config.coleccion, "article_id", models.PayloadSchemaType.KEYWORD)
    c.create_payload_index(config.coleccion, "content_hash", models.PayloadSchemaType.KEYWORD)


def hash_indexado(article_id: str) -> str | None:
    """Devuelve el content_hash con el que está indexado un artículo (o None)."""
    puntos, _ = cliente().scroll(
        collection_name=config.coleccion,
        scroll_filter=models.Filter(
            must=[models.FieldCondition(key="article_id", match=models.MatchValue(value=article_id))]
        ),
        limit=1,
        with_payload=["content_hash"],
        with_vectors=False,
    )
    if puntos:
        return puntos[0].payload.get("content_hash")
    return None


def borrar_articulo(article_id: str) -> None:
    """Elimina todos los chunks de un artículo (para sustituirlo por su nueva versión)."""
    cliente().delete(
        collection_name=config.coleccion,
        points_selector=models.FilterSelector(
            filter=models.Filter(
                must=[models.FieldCondition(key="article_id", match=models.MatchValue(value=article_id))]
            )
        ),
    )


def upsert_chunks(chunks: list[dict], vectores: list[list[float]]) -> None:
    """Inserta/actualiza una lista de chunks (cada uno con su payload) en lotes."""
    puntos = [
        models.PointStruct(
            id=punto_id(ch["article_id"], ch["chunk_index"]),
            vector=vec,
            payload=ch,
        )
        for ch, vec in zip(chunks, vectores)
    ]
    for i in range(0, len(puntos), 100):
        cliente().upsert(collection_name=config.coleccion, points=puntos[i:i + 100])


def borrar_obsoletos(ttl_dias: int = None) -> None:
    """Borra las noticias cuya fecha de publicación supera el TTL (delete-by-filter)."""
    dias = ttl_dias if ttl_dias is not None else config.ttl_dias
    corte = (datetime.now(timezone.utc) - timedelta(days=dias)).isoformat()
    cliente().delete(
        collection_name=config.coleccion,
        points_selector=models.FilterSelector(
            filter=models.Filter(
                must=[models.FieldCondition(key="published_at", range=models.DatetimeRange(lt=corte))]
            )
        ),
    )


def _construir_filtro(published_after: str | None, source: str | None,
                      language: str | None) -> models.Filter | None:
    condiciones = []
    if published_after:
        condiciones.append(
            models.FieldCondition(key="published_at", range=models.DatetimeRange(gte=published_after))
        )
    if source:
        condiciones.append(models.FieldCondition(key="source", match=models.MatchValue(value=source)))
    if language:
        condiciones.append(models.FieldCondition(key="language", match=models.MatchValue(value=language)))
    return models.Filter(must=condiciones) if condiciones else None


def buscar(query_vector: list[float], top_k: int = None, published_after: str | None = None,
           source: str | None = None, language: str | None = None) -> list[dict]:
    """Búsqueda vectorial ANN con filtros opcionales por metadatos."""
    respuesta = cliente().query_points(
        collection_name=config.coleccion,
        query=query_vector,
        limit=top_k or config.top_k,
        score_threshold=config.score_threshold,
        query_filter=_construir_filtro(published_after, source, language),
        search_params=models.SearchParams(hnsw_ef=config.hnsw_ef),
        with_payload=True,
    ).points

    return [
        {
            "content": p.payload.get("content", ""),
            "title": p.payload.get("title", ""),
            "source": p.payload.get("source", ""),
            "url": p.payload.get("url", ""),
            "published_at": p.payload.get("published_at", ""),
            "category": p.payload.get("category", ""),
            "score": p.score,
        }
        for p in respuesta
    ]


def contar() -> int:
    return cliente().get_collection(config.coleccion).points_count
