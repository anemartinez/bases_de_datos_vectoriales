"""
Configuración del sistema RAG de noticias.

Todos los parámetros se leen de variables de entorno (con valores por defecto
sensatos), de modo que el mismo código sirve en local y dentro de Docker sin
cambios. Esto es clave para que el servidor sea reproducible.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field


def _split(valor: str) -> list[str]:
    return [x.strip() for x in valor.split(",") if x.strip()]


@dataclass
class Config:
    # --- Qdrant ---
    qdrant_url: str = os.getenv("QDRANT_URL", "http://localhost:6333")
    coleccion: str = os.getenv("QDRANT_COLLECTION", "tech_news")

    # --- Modelo de embeddings (multilingüe, retrieval-strong; usa prefijos) ---
    modelo_embedding: str = os.getenv("EMBEDDING_MODEL", "intfloat/multilingual-e5-large")
    dim_embedding: int = int(os.getenv("EMBEDDING_DIM", "1024"))
    dispositivo: str = os.getenv("EMBEDDING_DEVICE", "cpu")

    # --- Chunking ---
    chunk_size: int = int(os.getenv("CHUNK_SIZE", "1500"))
    chunk_overlap: int = int(os.getenv("CHUNK_OVERLAP", "300"))

    # --- Recuperación ---
    top_k: int = int(os.getenv("TOP_K", "10"))            # candidatos de la fase vectorial
    top_n: int = int(os.getenv("TOP_N", "5"))             # contexto final tras el reranking
    score_threshold: float = float(os.getenv("SCORE_THRESHOLD", "0.0"))
    hnsw_ef: int = int(os.getenv("HNSW_EF", "128"))       # ef de búsqueda (recall vs. latencia)
    peso_vectorial: float = float(os.getenv("PESO_VECTORIAL", "0.7"))  # híbrido: 70% vector
    peso_bm25: float = float(os.getenv("PESO_BM25", "0.3"))           #          30% BM25

    # --- LLM ---
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    modelo_llm: str = os.getenv("LLM_MODEL", "gpt-4o-mini")
    temperatura_llm: float = float(os.getenv("LLM_TEMPERATURE", "0.1"))

    # --- Actualización / mantenimiento ---
    feeds: list[str] = field(default_factory=lambda: _split(os.getenv("RSS_FEEDS", "")))
    intervalo_minutos: int = int(os.getenv("UPDATE_EVERY_MINUTES", "30"))
    ttl_dias: int = int(os.getenv("TTL_DAYS", "30"))      # se borran noticias más antiguas
    scheduler_activo: bool = os.getenv("ENABLE_SCHEDULER", "false").lower() == "true"

    @property
    def hay_llm(self) -> bool:
        return bool(self.openai_api_key) and not self.openai_api_key.startswith("sk-tu")


config = Config()
