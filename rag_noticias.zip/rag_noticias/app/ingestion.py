"""
Pipeline de ingesta de noticias.

Fuentes soportadas:
  * Feeds RSS (feedparser) de medios tecnológicos.
  * Lista de artículos en JSON (para demo reproducible sin red).

Flujo por artículo:
  recolectar -> limpiar HTML -> calcular content_hash ->
  decidir (nuevo / actualizado / sin cambios) -> chunking -> embeddings ->
  upsert idempotente en Qdrant.

La deduplicación y la actualización se hacen a nivel de artículo usando un
`article_id` estable (derivado de la URL) y el `content_hash`:
  - artículo nuevo            -> se insertan sus chunks.
  - artículo con hash distinto -> se borran sus chunks viejos y se reinsertan.
  - artículo con mismo hash    -> se omite (no se vuelve a embeber: ahorro).
"""

from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

from bs4 import BeautifulSoup
from langchain_text_splitters import RecursiveCharacterTextSplitter

from .config import config
from .embeddings import embeder_pasajes
from . import vectorstore as vs


_splitter = RecursiveCharacterTextSplitter(
    chunk_size=config.chunk_size,
    chunk_overlap=config.chunk_overlap,
    separators=["\n\n", "\n", ". ", " ", ""],
)


def _hash(texto: str) -> str:
    return hashlib.sha256(texto.encode("utf-8")).hexdigest()


def _article_id(url: str) -> str:
    """Identificador estable de artículo a partir de la URL canónica."""
    url_limpia = re.sub(r"[#?].*$", "", url.strip().rstrip("/"))
    return hashlib.sha1(url_limpia.encode("utf-8")).hexdigest()[:16]


def limpiar_html(texto: str) -> str:
    soup = BeautifulSoup(texto or "", "html.parser")
    plano = soup.get_text(separator="\n")
    return "\n".join(linea.strip() for linea in plano.splitlines() if linea.strip())


def _chunks_de(articulo: dict) -> list[dict]:
    contenido = limpiar_html(articulo.get("content") or articulo.get("summary", ""))
    if not contenido.strip():
        return []
    h = _hash(contenido)
    trozos = _splitter.split_text(contenido)
    ahora = datetime.now(timezone.utc).isoformat()
    return [
        {
            "content": trozo,
            "title": articulo.get("title", ""),
            "source": articulo.get("source", ""),
            "url": articulo.get("url", ""),
            "published_at": articulo["published_at"],
            "article_id": articulo["article_id"],
            "content_hash": h,
            "chunk_index": i,
            "total_chunks": len(trozos),
            "language": articulo.get("language", "auto"),
            "category": articulo.get("category", "technology"),
            "ingested_at": ahora,
        }
        for i, trozo in enumerate(trozos)
    ]


def ingerir(articulos: list[dict]) -> dict:
    """Procesa una lista de artículos aplicando add/update/skip y los indexa."""
    vs.asegurar_coleccion()
    nuevos = actualizados = omitidos = chunks_total = 0

    for art in articulos:
        art.setdefault("article_id", _article_id(art["url"]))
        art.setdefault("published_at", datetime.now(timezone.utc).isoformat())

        chunks = _chunks_de(art)
        if not chunks:
            continue
        nuevo_hash = chunks[0]["content_hash"]
        hash_actual = vs.hash_indexado(art["article_id"])

        if hash_actual == nuevo_hash:
            omitidos += 1
            continue
        if hash_actual is not None:          # existe pero cambió -> actualizar
            vs.borrar_articulo(art["article_id"])
            actualizados += 1
        else:
            nuevos += 1

        vectores = embeder_pasajes([c["content"] for c in chunks])
        vs.upsert_chunks(chunks, vectores)
        chunks_total += len(chunks)

    return {
        "recibidos": len(articulos),
        "nuevos": nuevos,
        "actualizados": actualizados,
        "omitidos_sin_cambios": omitidos,
        "chunks_indexados": chunks_total,
    }


def cargar_muestra(ruta: str | Path = None) -> list[dict]:
    ruta = Path(ruta or Path(__file__).resolve().parent.parent / "data" / "sample_articles.json")
    with open(ruta, encoding="utf-8") as fh:
        return json.load(fh)


def descargar_rss(feeds: list[str] = None, max_por_feed: int = 20) -> list[dict]:
    """Descarga artículos recientes de una lista de feeds RSS (requiere red)."""
    import feedparser  # import perezoso: solo se necesita para ingesta en vivo

    feeds = feeds or config.feeds
    articulos: list[dict] = []
    for feed_url in feeds:
        feed = feedparser.parse(feed_url)
        fuente = feed.feed.get("title", feed_url)
        for entrada in feed.entries[:max_por_feed]:
            publicado = entrada.get("published_parsed") or entrada.get("updated_parsed")
            fecha = (
                datetime(*publicado[:6], tzinfo=timezone.utc).isoformat()
                if publicado else datetime.now(timezone.utc).isoformat()
            )
            contenido = ""
            if entrada.get("content"):
                contenido = entrada["content"][0].get("value", "")
            contenido = contenido or entrada.get("summary", "")
            articulos.append(
                {
                    "title": entrada.get("title", ""),
                    "url": entrada.get("link", ""),
                    "summary": entrada.get("summary", ""),
                    "content": contenido,
                    "source": fuente,
                    "published_at": fecha,
                    "article_id": _article_id(entrada.get("link", "")),
                    "language": "auto",
                    "category": "technology",
                }
            )
    return articulos


def actualizar_desde_feeds(feeds: list[str] = None) -> dict:
    """Job de actualización: descarga de RSS, indexa y poda lo obsoleto (TTL)."""
    articulos = descargar_rss(feeds)
    stats = ingerir(articulos)
    vs.borrar_obsoletos()
    stats["total_en_bd"] = vs.contar()
    return stats
