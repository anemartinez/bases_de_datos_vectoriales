"""
Planificador de actualización periódica (APScheduler).

Ejecuta el job de ingesta desde RSS cada `UPDATE_EVERY_MINUTES` y poda las
noticias obsoletas según el TTL. Se activa con ENABLE_SCHEDULER=true y solo
tiene sentido si se han configurado feeds en RSS_FEEDS.
"""

from __future__ import annotations

import logging

from apscheduler.schedulers.background import BackgroundScheduler

from .config import config
from .ingestion import actualizar_desde_feeds

log = logging.getLogger("scheduler")
_scheduler: BackgroundScheduler | None = None


def _job():
    try:
        stats = actualizar_desde_feeds()
        log.info("Actualización RSS: %s", stats)
    except Exception as exc:  # noqa: BLE001
        log.exception("Fallo en la actualización programada: %s", exc)


def iniciar() -> BackgroundScheduler | None:
    global _scheduler
    if not config.scheduler_activo:
        return None
    if not config.feeds:
        log.warning("ENABLE_SCHEDULER=true pero RSS_FEEDS está vacío; no se programa nada.")
        return None
    _scheduler = BackgroundScheduler(timezone="UTC")
    _scheduler.add_job(_job, "interval", minutes=config.intervalo_minutos, next_run_time=None)
    _scheduler.start()
    log.info("Scheduler iniciado: cada %d min.", config.intervalo_minutos)
    return _scheduler


def detener():
    if _scheduler is not None:
        _scheduler.shutdown(wait=False)
