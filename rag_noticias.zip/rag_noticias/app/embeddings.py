"""
Servicio de embeddings con multilingual-e5-large.

La familia E5 se entrenó con prefijos de instrucción y los REQUIERE:
  - "query: "   para las consultas del usuario.
  - "passage: " para los fragmentos del corpus.
Omitirlos degrada la recuperación. Los vectores se normalizan (norma 1) para
que el producto escalar equivalga a la similitud coseno que usa Qdrant.

El modelo se carga una sola vez (patrón singleton) y se reutiliza en toda la
aplicación, porque cargarlo es lo más costoso del arranque.
"""

from __future__ import annotations

from functools import lru_cache

from sentence_transformers import SentenceTransformer

from .config import config


@lru_cache(maxsize=1)
def _modelo() -> SentenceTransformer:
    return SentenceTransformer(config.modelo_embedding, device=config.dispositivo)


def embeder_pasajes(textos: list[str]) -> list[list[float]]:
    """Vectoriza fragmentos del corpus (prefijo 'passage: ')."""
    entradas = [f"passage: {t}" for t in textos]
    vectores = _modelo().encode(
        entradas, normalize_embeddings=True, convert_to_numpy=True, show_progress_bar=False
    )
    return vectores.tolist()


def embeder_consulta(consulta: str) -> list[float]:
    """Vectoriza una consulta del usuario (prefijo 'query: ')."""
    vector = _modelo().encode(
        f"query: {consulta}", normalize_embeddings=True, convert_to_numpy=True
    )
    return vector.tolist()
