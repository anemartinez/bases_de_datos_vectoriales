"""
Servidor REST del sistema RAG (FastAPI).

Expone el producto como un servicio replicable y desplegable, no como un
notebook. Endpoints principales:

  GET  /health              -> estado del servicio y nº de vectores.
  POST /ask                 -> pregunta -> respuesta RAG + fuentes.
  POST /ingest/sample       -> indexa el corpus de muestra (demo sin red).
  POST /ingest/rss          -> descarga e indexa desde feeds RSS.
  POST /maintenance/prune   -> borra noticias obsoletas (TTL).
  GET  /stats               -> nº de vectores indexados.

Al arrancar asegura la colección de Qdrant y, si procede, lanza el scheduler.
"""

from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI
from pydantic import BaseModel

from .config import config
from . import vectorstore as vs
from . import ingestion
from . import rag
from . import scheduler


@asynccontextmanager
async def lifespan(app: FastAPI):
    vs.asegurar_coleccion()
    scheduler.iniciar()
    yield
    scheduler.detener()


app = FastAPI(title="RAG de noticias de tecnología e IA", version="1.0", lifespan=lifespan)


class PreguntaIn(BaseModel):
    question: str
    top_k: int | None = None
    published_after: str | None = None   # ISO-8601, p. ej. "2026-03-01T00:00:00+00:00"
    source: str | None = None
    use_hybrid: bool = True


class RSSIn(BaseModel):
    feeds: list[str] | None = None


class PruneIn(BaseModel):
    ttl_days: int | None = None


@app.get("/health")
def health():
    try:
        n = vs.contar()
        estado = "ok"
    except Exception:  # noqa: BLE001
        n, estado = 0, "qdrant_no_disponible"
    return {"status": estado, "vectores": n, "modelo_embedding": config.modelo_embedding,
            "llm": config.modelo_llm if config.hay_llm else "desactivado (modo extractivo)"}


@app.get("/stats")
def stats():
    return {"vectores": vs.contar(), "coleccion": config.coleccion}


@app.post("/ask")
def ask(p: PreguntaIn):
    return rag.responder(
        p.question, top_k=p.top_k, published_after=p.published_after,
        source=p.source, usar_hibrido=p.use_hybrid,
    )


@app.post("/ingest/sample")
def ingest_sample():
    return ingestion.ingerir(ingestion.cargar_muestra())


@app.post("/ingest/rss")
def ingest_rss(body: RSSIn):
    return ingestion.actualizar_desde_feeds(body.feeds)


@app.post("/maintenance/prune")
def prune(body: PruneIn):
    vs.borrar_obsoletos(body.ttl_days)
    return {"status": "ok", "vectores_restantes": vs.contar()}
