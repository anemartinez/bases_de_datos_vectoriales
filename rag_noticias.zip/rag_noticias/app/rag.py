"""
Motor RAG: orquesta recuperación + generación.

Flujo: pregunta -> embedding (query:) -> búsqueda vectorial en Qdrant
(con filtros opcionales de recencia/fuente) -> reranking híbrido (vectorial +
BM25) -> construcción del prompt con contexto y citas -> LLM -> respuesta.

Optimización del contexto:
  * filtros por recencia/fuente antes de recuperar,
  * reranking híbrido (la señal léxica de BM25 ayuda con términos técnicos
    exactos que el vector a veces no distingue),
  * recorte del contexto a top_n para no saturar la ventana del LLM,
  * prompt que obliga a responder solo con el contexto y a citar fuentes.

Si no hay clave de OpenAI, devuelve el contexto recuperado (modo extractivo),
de modo que el sistema es demostrable end-to-end sin coste.
"""

from __future__ import annotations

from rank_bm25 import BM25Okapi

from .config import config
from .embeddings import embeder_consulta
from . import vectorstore as vs


SYSTEM_PROMPT = (
    "Eres un asistente especializado en noticias de tecnología e inteligencia artificial. "
    "Responde basándote SOLO en el contexto proporcionado; no inventes datos. "
    "Si el contexto no es suficiente, dilo claramente. "
    "Prioriza la información más reciente y cita las fuentes utilizadas al final. "
    "Responde en el idioma de la pregunta."
)


def _rerank_hibrido(pregunta: str, resultados: list[dict], top_n: int) -> list[dict]:
    if not resultados:
        return resultados
    corpus = [r["content"].lower().split() for r in resultados]
    bm25 = BM25Okapi(corpus)
    puntuaciones = bm25.get_scores(pregunta.lower().split())
    maximo = max(puntuaciones) if max(puntuaciones, default=0) > 0 else 1.0
    for r, s in zip(resultados, puntuaciones):
        r["hybrid_score"] = config.peso_vectorial * r["score"] + config.peso_bm25 * (s / maximo)
    resultados.sort(key=lambda x: x["hybrid_score"], reverse=True)
    return resultados[:top_n]


def _construir_contexto(resultados: list[dict]) -> str:
    bloques = []
    for i, r in enumerate(resultados, 1):
        bloques.append(f"[{i}] {r['title']} ({r['source']}, {r['published_at']})\n{r['content']}")
    return "\n---\n".join(bloques)


def _generar_con_llm(pregunta: str, contexto: str) -> str:
    from openai import OpenAI

    cliente = OpenAI(api_key=config.openai_api_key)
    respuesta = cliente.chat.completions.create(
        model=config.modelo_llm,
        temperature=config.temperatura_llm,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"Contexto:\n{contexto}\n\nPregunta: {pregunta}"},
        ],
    )
    return respuesta.choices[0].message.content


def responder(pregunta: str, top_k: int = None, published_after: str | None = None,
              source: str | None = None, usar_hibrido: bool = True) -> dict:
    vector = embeder_consulta(pregunta)
    resultados = vs.buscar(vector, top_k=top_k, published_after=published_after, source=source)

    if not resultados:
        return {"answer": "No encontré información relevante en la base de noticias.",
                "sources": [], "chunks_retrieved": 0}

    if usar_hibrido and len(resultados) > 1:
        resultados = _rerank_hibrido(pregunta, resultados, config.top_n)
    else:
        resultados = resultados[: config.top_n]

    contexto = _construir_contexto(resultados)
    if config.hay_llm:
        answer = _generar_con_llm(pregunta, contexto)
    else:
        answer = f"(Modo extractivo, sin LLM) Contexto recuperado:\n\n{contexto}"

    fuentes = [
        {
            "title": r["title"],
            "source": r["source"],
            "url": r["url"],
            "published_at": r["published_at"],
            "relevance_score": round(r.get("hybrid_score", r["score"]), 4),
        }
        for r in resultados
    ]
    return {"answer": answer, "sources": fuentes, "chunks_retrieved": len(resultados)}
