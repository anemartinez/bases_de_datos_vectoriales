"""Sistema RAG de noticias de tecnología e IA con información actualizada."""
