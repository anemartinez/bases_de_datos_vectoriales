"""Carga el corpus de muestra en Qdrant (demo reproducible sin red).

Uso:  python -m scripts.ingest_sample
"""
from app import ingestion, vectorstore as vs

if __name__ == "__main__":
    vs.asegurar_coleccion()
    stats = ingestion.ingerir(ingestion.cargar_muestra())
    print("Ingesta de muestra:", stats)
    print("Total en Qdrant:", vs.contar())
